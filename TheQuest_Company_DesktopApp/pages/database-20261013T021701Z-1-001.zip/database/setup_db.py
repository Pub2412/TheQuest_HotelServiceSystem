import sqlite3
import os

def create_database():
    # Define the absolute path to the database file in the same directory as this script
    db_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(db_dir, 'hotel_service.db')
    
    # Connect to the SQLite database (this will create the file if it doesn't exist)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Users (Employees and Admins)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL, -- Admin, Cashier, Staff_Kitchen, Staff_Logistics, Staff_Utilities
        name TEXT NOT NULL,
        phone TEXT,
        image_path TEXT
    )
    ''')

    # Customers
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        mobile_number TEXT UNIQUE,
        password_hash TEXT,
        name TEXT NOT NULL,
        loyalty_points INTEGER DEFAULT 0,
        google_id TEXT,
        facebook_id TEXT
    )
    ''')

    # Rooms
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_number TEXT UNIQUE NOT NULL,
        type TEXT,
        price_per_night REAL NOT NULL,
        status TEXT DEFAULT 'Vacant' -- Vacant, Occupied, Needs Service
    )
    ''')

    # Reservations
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS reservations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        room_id INTEGER,
        check_in_date DATE,
        check_out_date DATE,
        status TEXT DEFAULT 'Pending', -- Pending, Checked In, Checked Out, Canceled
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(room_id) REFERENCES rooms(id)
    )
    ''')

    # Transactions (Revenue and Costs)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT, -- Revenue, Cost_Utility, Cost_Goods
        amount REAL,
        description TEXT,
        date_recorded DATETIME DEFAULT CURRENT_TIMESTAMP,
        customer_id INTEGER,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    )
    ''')

    # Inventory (Ingredients & Goods)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_name TEXT NOT NULL,
        category TEXT, -- Kitchen, Utility
        quantity INTEGER DEFAULT 0,
        low_stock_threshold INTEGER DEFAULT 10
    )
    ''')

    # Deliveries (Logistics)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS deliveries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        description TEXT,
        status TEXT DEFAULT 'Will be Shipped', -- Will be Shipped, On the Way, Near Receive, Completed, Canceled
        logistics_code TEXT,
        date_updated DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Service Requests
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS service_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_id INTEGER,
        customer_id INTEGER,
        request_type TEXT, -- Food Delivery, Room Service
        details TEXT,
        status TEXT DEFAULT 'Processing', -- Processing, Complete, Canceled
        FOREIGN KEY(room_id) REFERENCES rooms(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    )
    ''')

    # Messages (Inbox)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER,
        receiver_id INTEGER,
        receiver_role TEXT, -- To allow sending to a group, e.g., 'Staff_Kitchen'
        content TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(sender_id) REFERENCES users(id),
        FOREIGN KEY(receiver_id) REFERENCES users(id)
    )
    ''')

    # Employee Bulletin
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS bulletin (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        author_id INTEGER,
        title TEXT,
        content TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(author_id) REFERENCES users(id)
    )
    ''')

    # Loyalty Rewards
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS loyalty_rewards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reward_name TEXT,
        points_required INTEGER,
        description TEXT
    )
    ''')

    conn.commit()
    conn.close()
    print(f"Database successfully created/connected at: {db_path}")

if __name__ == "__main__":
    create_database()
